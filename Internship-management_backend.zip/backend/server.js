const express = require('express');
const cors = require('cors');
require('dotenv').config();

// Import DB connection
const pool = require('./config/db');

// Import routes
const authRoutes = require('./routes/authRoutes');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/auth', authRoutes);

// Base route
app.get('/', (req, res) => {
  res.json({ 
    message: '🚀 Internship Management System API is running!',
    status: 'success',
    version: '1.0.0'
  });
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`✅ Server running on http://localhost:${PORT}`);
});
