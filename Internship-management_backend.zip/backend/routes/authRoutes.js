const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { verifyToken } = require('../middleware/authMiddleware');

// Public routes (no token needed)
router.post('/register', authController.register);
router.post('/login', authController.login);

// Protected route (token required)
router.get('/me', verifyToken, authController.getMe);

module.exports = router;