const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const userModel = require('../models/userModel');

const authController = {

  // REGISTER
  register: async (req, res) => {
    try {
      const { email, password, role } = req.body;

      // 1. Validate input
      if (!email || !password || !role) {
        return res.status(400).json({ 
          message: 'Email, password and role are required' 
        });
      }

      // 2. Check if valid role
      const validRoles = ['admin', 'hr', 'mentor', 'intern'];
      if (!validRoles.includes(role)) {
        return res.status(400).json({ 
          message: 'Invalid role. Must be admin, hr, mentor or intern' 
        });
      }

      // 3. Check if user already exists
      const existingUser = await userModel.findByEmail(email);
      if (existingUser) {
        return res.status(400).json({ 
          message: 'User with this email already exists' 
        });
      }

      // 4. Hash the password (10 = salt rounds, higher = more secure but slower)
      const hashedPassword = await bcrypt.hash(password, 10);

      // 5. Save user to database
      const newUser = await userModel.createUser(email, hashedPassword, role);

      // 6. Return success
      res.status(201).json({
        message: '✅ User registered successfully',
        user: newUser
      });

    } catch (error) {
      console.error('Register error:', error.message);
      res.status(500).json({ message: 'Server error during registration' });
    }
  },

  // LOGIN
  login: async (req, res) => {
    try {
      const { email, password } = req.body;

      // 1. Validate input
      if (!email || !password) {
        return res.status(400).json({ 
          message: 'Email and password are required' 
        });
      }

      // 2. Find user by email
      const user = await userModel.findByEmail(email);
      if (!user) {
        return res.status(401).json({ 
          message: 'Invalid email or password' 
        });
      }

      // 3. Check if account is active
      if (!user.is_active) {
        return res.status(401).json({ 
          message: 'Account is deactivated. Contact admin.' 
        });
      }

      // 4. Compare password with hashed password
      const isPasswordValid = await bcrypt.compare(password, user.password);
      if (!isPasswordValid) {
        return res.status(401).json({ 
          message: 'Invalid email or password' 
        });
      }

      // 5. Generate JWT token
      const token = jwt.sign(
        { id: user.id, role: user.role },  // payload (data inside token)
        process.env.JWT_SECRET,             // secret key
        { expiresIn: '7d' }                 // token expires in 7 days
      );

      // 6. Return token
      res.status(200).json({
        message: '✅ Login successful',
        token,
        user: {
          id: user.id,
          email: user.email,
          role: user.role
        }
      });

    } catch (error) {
      console.error('Login error:', error.message);
      res.status(500).json({ message: 'Server error during login' });
    }
  },

  // GET LOGGED IN USER
  getMe: async (req, res) => {
    try {
      const user = await userModel.findById(req.user.id);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      res.status(200).json({ user });
    } catch (error) {
      console.error('GetMe error:', error.message);
      res.status(500).json({ message: 'Server error' });
    }
  }

};

module.exports = authController;
